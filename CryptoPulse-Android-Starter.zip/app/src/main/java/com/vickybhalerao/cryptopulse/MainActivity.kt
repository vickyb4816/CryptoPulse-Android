package com.vickybhalerao.cryptopulse

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.URL
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF07131F)
private val Panel = Color(0xFF102333)
private val Green = Color(0xFF35E0AE)
private val Red = Color(0xFFFF6577)
private val Muted = Color(0xFF91A9BA)
private val White = Color(0xFFEAF4FA)
private val inr = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

data class Ticker(val symbol: String, val last: Double, val change: Double, val quoteVolume: Double)
data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)

interface MarketDataProvider {
    suspend fun tickers(): List<Ticker>
    suspend fun candles(symbol: String, interval: String): List<Candle>
}

/** First exchange adapter. Add Coinbase/Kraken/etc by implementing MarketDataProvider. */
class BinanceSpotProvider : MarketDataProvider {
    override suspend fun tickers(): List<Ticker> = withContext(Dispatchers.IO) {
        val json = JSONArray(URL("https://data-api.binance.vision/api/v3/ticker/24hr").readText())
        buildList {
            for (i in 0 until json.length()) {
                val o = json.getJSONObject(i)
                val symbol = o.optString("symbol")
                if (symbol.endsWith("USDT") && symbol.length <= 12) {
                    add(Ticker(symbol, o.optString("lastPrice").toDoubleOrNull() ?: 0.0,
                        o.optString("priceChangePercent").toDoubleOrNull() ?: 0.0,
                        o.optString("quoteVolume").toDoubleOrNull() ?: 0.0))
                }
            }
        }.sortedByDescending { it.quoteVolume }.take(100)
    }
    override suspend fun candles(symbol: String, interval: String): List<Candle> = withContext(Dispatchers.IO) {
        val json = JSONArray(URL("https://data-api.binance.vision/api/v3/klines?symbol=$symbol&interval=$interval&limit=100").readText())
        buildList {
            for (i in 0 until json.length()) {
                val a = json.getJSONArray(i)
                add(Candle(a.getLong(0), a.getString(1).toDouble(), a.getString(2).toDouble(),
                    a.getString(3).toDouble(), a.getString(4).toDouble(), a.getString(5).toDouble()))
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CryptoPulseApp() }
    }
}

@Composable
fun CryptoPulseApp() {
    val provider = remember { BinanceSpotProvider() }
    var tab by remember { mutableStateOf("Markets") }
    var tickers by remember { mutableStateOf<List<Ticker>>(emptyList()) }
    var selected by remember { mutableStateOf("BTCUSDT") }
    var interval by remember { mutableStateOf("1h") }
    var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var status by remember { mutableStateOf("Connecting to Binance public market data…") }
    var search by remember { mutableStateOf("") }
    var demoCash by remember { mutableDoubleStateOf(100000.0) }
    var demoTrades by remember { mutableStateOf(listOf<String>()) }
    var tradeValue by remember { mutableStateOf("10000") }
    var condition by remember { mutableStateOf("EMA 9 crosses above EMA 21") }
    var backtest by remember { mutableStateOf<Backtest?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                tickers = provider.tickers()
                status = "Live market data · refreshed just now"
            } catch (e: Exception) {
                status = "Market data unavailable. Check connection and retry."
            }
            delay(15_000)
        }
    }
    LaunchedEffect(selected, interval) {
        try {
            candles = provider.candles(selected, interval)
            backtest = runBacktest(candles)
        } catch (_: Exception) {
            candles = emptyList()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onBackground = White, onSurface = White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF091A28)) {
                listOf("Markets", "Chart", "Strategies", "Backtest", "Demo").forEach {
                    NavigationBarItem(selected = tab == it, onClick = { tab = it },
                        icon = { Text(when(it) {"Markets"->"⌕";"Chart"->"⌁";"Strategies"->"⚙";"Backtest"->"▥";else->"₹"}, fontSize=19.sp) },
                        label = { Text(it, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor=Green, selectedTextColor=Green,
                            indicatorColor=Panel, unselectedTextColor=Muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top=16.dp, bottom=12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("CryptoPulse", color=Green, fontSize=26.sp, fontWeight=FontWeight.Bold)
                        Text("Scan · Analyse · Trade · Grow", color=Muted, fontSize=11.sp)
                    }
                    Text("v1.1", color=Muted, fontSize=12.sp)
                }
                when(tab) {
                    "Markets" -> MarketScreen(tickers, status, search, { search=it }, { selected=it; tab="Chart" })
                    "Chart" -> ChartScreen(selected, { selected=it }, interval, { interval=it }, candles)
                    "Strategies" -> StrategyScreen(condition, { condition=it }, candles)
                    "Backtest" -> BacktestScreen(backtest, selected, interval)
                    else -> DemoScreen(demoCash, {demoCash=it}, demoTrades, {demoTrades=it}, tradeValue, {tradeValue=it},
                        tickers.firstOrNull { it.symbol == selected }?.last ?: 0.0, selected)
                }
                Spacer(Modifier.height(8.dp))
                Text("All rights reserved · Made by Vicky Bhalerao · Oct 2026", color=Muted, fontSize=9.sp,
                    modifier=Modifier.fillMaxWidth().padding(bottom=8.dp))
            }
        }
    }
}

@Composable
fun MarketScreen(tickers: List<Ticker>, status: String, search: String, onSearch: (String)->Unit, onSelect:(String)->Unit) {
    Text(status, color=if(status.startsWith("Live")) Green else Muted, fontSize=11.sp)
    Spacer(Modifier.height(10.dp))
    OutlinedTextField(search, onSearch, modifier=Modifier.fillMaxWidth(), singleLine=true,
        placeholder={Text("Search coin, e.g. BTCUSDT")}, colors=fieldColors())
    Row(Modifier.fillMaxWidth().padding(vertical=10.dp), horizontalArrangement=Arrangement.SpaceBetween) {
        Text("PAIR", color=Muted, fontSize=10.sp); Text("LAST PRICE", color=Muted, fontSize=10.sp); Text("24H", color=Muted, fontSize=10.sp)
    }
    LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)) {
        items(tickers.filter { it.symbol.contains(search.trim().uppercase()) }) { t ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).clickable { onSelect(t.symbol) }.padding(12.dp),
                verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.symbol, color=White, fontWeight=FontWeight.SemiBold)
                    Text("Vol ${compact(t.quoteVolume)} USDT", color=Muted, fontSize=10.sp)
                }
                Text(t.last.pretty(), color=White, fontSize=12.sp)
                Spacer(Modifier.width(12.dp))
                Text("${if(t.change>=0) "+" else ""}${"%.2f".format(t.change)}%", color=if(t.change>=0) Green else Red, fontSize=12.sp)
            }
        }
    }
}

@Composable
fun ChartScreen(symbol:String, onSymbol:(String)->Unit, interval:String, onInterval:(String)->Unit, candles:List<Candle>) {
    Row(verticalAlignment=Alignment.CenterVertically) {
        Text(symbol, color=White, fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
        Text("● LIVE", color=Green, fontSize=10.sp)
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
        listOf("1m","5m","15m","30m","1h","4h","1d","1w","1M").forEach {
            FilterChip(selected=interval==it, onClick={onInterval(it)}, label={Text(it)}, colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Green, selectedLabelColor=Bg))
        }
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        listOf("BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT").forEach { Text(it, color=if(it==symbol) Green else Muted, modifier=Modifier.clickable{onSymbol(it)}.padding(4.dp), fontSize=11.sp) }
    }
    Box(Modifier.fillMaxWidth().height(290.dp).background(Panel, RoundedCornerShape(16.dp)).padding(8.dp)) {
        if(candles.isEmpty()) Text("Loading candles…", color=Muted, modifier=Modifier.align(Alignment.Center))
        else CandleChart(candles)
    }
    Spacer(Modifier.height(10.dp))
    Text("Indicators", color=White, fontWeight=FontWeight.Bold)
    Text("EMA 9 / EMA 21 · RSI(14) · MACD · Volume (indicator overlays are on the roadmap)", color=Muted, fontSize=11.sp)
    Spacer(Modifier.height(8.dp))
    Text("Signal preview: ${signalFor(candles)}", color=Green, fontSize=13.sp)
    Text("Entry / SL / targets are simulated analytical levels, not execution instructions.", color=Muted, fontSize=10.sp)
}

@Composable
fun CandleChart(candles:List<Candle>) {
    Canvas(Modifier.fillMaxSize()) {
        val data = candles.takeLast(65)
        if(data.isEmpty()) return@Canvas
        val minP = data.minOf { it.low }; val maxP = data.maxOf { it.high }
        val range = (maxP-minP).takeIf { it>0 } ?: 1.0
        fun y(p:Double) = size.height - ((p-minP)/range).toFloat()*size.height
        for(i in 1..4) drawLine(Color(0xFF243B4C), Offset(0f,size.height*i/5), Offset(size.width,size.height*i/5), 1f)
        val step = size.width/data.size
        data.forEachIndexed { i,c ->
            val x=step*i+step/2
            val color=if(c.close>=c.open) Green else Red
            drawLine(color, Offset(x,y(c.high)), Offset(x,y(c.low)), 2f)
            val top=min(y(c.open),y(c.close)); val bottom=max(y(c.open),y(c.close))
            drawRect(color, Offset(x-step*.27f,top), androidx.compose.ui.geometry.Size(step*.54f,max(2f,bottom-top)))
        }
    }
}

@Composable
fun StrategyScreen(condition:String, onCondition:(String)->Unit, candles:List<Candle>) {
    Text("Strategy Lab", color=White, fontSize=21.sp, fontWeight=FontWeight.Bold)
    Text("Build rule combinations without writing code.", color=Muted, fontSize=12.sp)
    Spacer(Modifier.height(12.dp))
    Text("WHEN this condition is true", color=Green, fontWeight=FontWeight.SemiBold)
    listOf("EMA 9 crosses above EMA 21","RSI crosses above 30","MACD line crosses above signal","Close breaks above 20-candle high","Volume exceeds 2× average").forEach {
        Row(Modifier.fillMaxWidth().padding(vertical=3.dp).background(if(condition==it) Color(0xFF17483F) else Panel, RoundedCornerShape(10.dp))
            .clickable { onCondition(it) }.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
            RadioButton(selected=condition==it, onClick={onCondition(it)}, colors=RadioButtonDefaults.colors(selectedColor=Green))
            Text(it, color=White, fontSize=12.sp)
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("THEN", color=Green, fontWeight=FontWeight.SemiBold)
    Text("Generate BUY/SELL signal · Suggested SL: 1.5 × ATR · Target: 2R", color=White, fontSize=12.sp,
        modifier=Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(10.dp)).padding(12.dp))
    Spacer(Modifier.height(12.dp))
    Text("Current market signal: ${signalFor(candles)}", color=Green)
    Text("Custom rules are a starter UI; save/load and multi-condition AND/OR logic are next build tasks.", color=Muted, fontSize=10.sp)
}

data class Backtest(val trades:Int, val wins:Int, val winRate:Double, val maxDrawdown:Double, val netPct:Double)
fun runBacktest(c:List<Candle>):Backtest {
    if(c.size<25) return Backtest(0,0,0.0,0.0,0.0)
    val closes=c.map{it.close}
    fun ema(end:Int, period:Int):Double {
        val start=max(0,end-period*4)
        val alpha=2.0/(period+1)
        var e=closes[start]
        for(i in start+1..end) e=closes[i]*alpha+e*(1-alpha)
        return e
    }
    var position:Double?=null; var equity=1.0; var peak=1.0; var maxDd=0.0; var trades=0; var wins=0
    for(i in 22 until c.size) {
        val fast=ema(i,9); val slow=ema(i,21)
        if(position==null && fast>slow && ema(i-1,9)<=ema(i-1,21)) position=closes[i]
        else if(position!=null && fast<slow && ema(i-1,9)>=ema(i-1,21)) {
            val ret=closes[i]/position!!-1
            equity*=1+ret
            trades++; if(ret>0) wins++
            position=null; peak=max(peak,equity); maxDd=max(maxDd,(peak-equity)/peak)
        }
    }
    return Backtest(trades,wins,if(trades>0)wins*100.0/trades else 0.0,maxDd*100,(equity-1)*100)
}
fun signalFor(c:List<Candle>):String {
    if(c.size<22) return "Waiting for data"
    val recent=c.takeLast(21).map{it.close}
    val e9=recent.takeLast(9).average()
    val e21=recent.average()
    return if(e9>e21) "Bullish trend (EMA proxy)" else "Bearish / neutral trend (EMA proxy)"
}

@Composable
fun BacktestScreen(bt:Backtest?, symbol:String, interval:String) {
    Text("Backtest", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold)
    Text("$symbol · $interval · EMA crossover sample", color=Muted, fontSize=12.sp)
    Spacer(Modifier.height(12.dp))
    if(bt==null) Text("Loading historical candles…", color=Muted)
    else {
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StatCard("Trades", "${bt.trades}", Modifier.weight(1f))
            StatCard("Win rate", "${"%.1f".format(bt.winRate)}%", Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            StatCard("Max drawdown", "${"%.2f".format(bt.maxDrawdown)}%", Modifier.weight(1f))
            StatCard("Net return", "${"%.2f".format(bt.netPct)}%", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Text("Methodology", color=Green, fontWeight=FontWeight.Bold)
        Text("EMA crossover on currently fetched candles. This sample excludes robust fees, slippage, open positions, walk-forward testing and exchange-specific execution effects.", color=Muted, fontSize=11.sp)
        Text("Do not use this report alone to choose a live trading strategy.", color=Red, fontSize=11.sp)
    }
}
@Composable fun StatCard(label:String,value:String,modifier:Modifier=Modifier) {
    Column(modifier.background(Panel,RoundedCornerShape(12.dp)).padding(14.dp)) {
        Text(label,color=Muted,fontSize=11.sp); Spacer(Modifier.height(4.dp)); Text(value,color=Green,fontSize=20.sp,fontWeight=FontWeight.Bold)
    }
}

@Composable
fun DemoScreen(cash:Double, setCash:(Double)->Unit, trades:List<String>, setTrades:(List<String>)->Unit,
               value:String, setValue:(String)->Unit, price:Double, symbol:String) {
    Text("Paper Trading", color=White, fontSize=22.sp, fontWeight=FontWeight.Bold)
    Text("Virtual funds only · no real orders", color=Muted, fontSize=12.sp)
    Spacer(Modifier.height(12.dp))
    Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(16.dp)).padding(18.dp)) {
        Text("AVAILABLE DEMO CASH", color=Muted, fontSize=10.sp)
        Text(inr.format(cash), color=Green, fontSize=28.sp, fontWeight=FontWeight.Bold)
        Text("Starting balance: ₹1,00,000", color=Muted, fontSize=11.sp)
    }
    Spacer(Modifier.height(12.dp))
    Text("Selected pair: $symbol", color=White)
    Text("Market reference: ${if(price>0) price.pretty() else "loading"} USDT", color=Muted, fontSize=11.sp)
    OutlinedTextField(value,setValue, modifier=Modifier.fillMaxWidth(), label={Text("Order value (₹)")}, singleLine=true, colors=fieldColors())
    Spacer(Modifier.height(8.dp))
    Button(onClick={
        val amount=value.toDoubleOrNull()
        if(amount!=null && amount>0 && amount<=cash) {
            setCash(cash-amount); setTrades(listOf("BUY $symbol · ₹${"%.2f".format(amount)} · ${java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(java.util.Date())}")+trades)
        }
    }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)) { Text("Place virtual buy") }
    OutlinedButton(onClick={setCash(100000.0);setTrades(emptyList())}, modifier=Modifier.fillMaxWidth()) { Text("Reset demo account") }
    Spacer(Modifier.height(12.dp))
    Text("Order history", color=White, fontWeight=FontWeight.Bold)
    if(trades.isEmpty()) Text("No virtual trades yet.", color=Muted, fontSize=12.sp)
    trades.take(10).forEach { Text(it,color=White,fontSize=11.sp,modifier=Modifier.fillMaxWidth().padding(vertical=5.dp)) }
    Text("MVP note: demo ledger is in-memory and resets when the app process is recreated.", color=Muted, fontSize=10.sp)
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor=White, unfocusedTextColor=White,
    focusedBorderColor=Green, unfocusedBorderColor=Muted,
    focusedLabelColor=Green, unfocusedLabelColor=Muted,
    cursorColor=Green
)
fun Double.pretty():String = if(this>=1000) "%,.2f".format(this) else "%,.6f".format(this)
fun compact(v:Double):String = when {v>=1e9->"%.1fB".format(v/1e9);v>=1e6->"%.1fM".format(v/1e6);v>=1e3->"%.1fK".format(v/1e3);else->"%.0f".format(v)}
