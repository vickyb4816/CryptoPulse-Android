# CryptoPulse Android — Starter Project
**Version 1.1 · October 2026 · All rights reserved · Made by Vicky Bhalerao**

CryptoPulse is a Kotlin + Jetpack Compose starter app with:
- Live Binance Spot market tickers (public endpoints, no API key)
- Candle history and a lightweight custom candlestick chart
- Timeframe selection
- Simple EMA crossover strategy signal
- Educational historical backtest summary (win rate and max drawdown)
- ₹1,00,000 virtual paper-trading cash balance and local demo buy/sell ledger
- Visual no-code strategy condition selector
- Exchange provider abstraction notes for adding other venues

## Open and run
1. Install Android Studio and a compatible Android SDK.
2. Open this folder in Android Studio.
3. Let Gradle sync complete.
4. Run the `app` configuration on an Android device/emulator (min SDK 26).

This source project is APK-buildable in Android Studio; a prebuilt APK is not included because the build requires the Android SDK/Gradle environment.

## Market data
Uses Binance public Spot REST endpoints:
- `https://data-api.binance.vision/api/v3/ticker/24hr`
- `https://data-api.binance.vision/api/v3/klines?symbol=BTCUSDT&interval=1h&limit=100`

Live updates are polled every 15 seconds while the app is open. For production, replace polling with resilient WebSocket streams and implement reconnect/backoff, stale-data indicators, server-side push alerts, rate-limit handling and exchange-specific adapters. Other exchange providers are represented by the `MarketDataProvider` interface; Binance is the first implementation.

## Important limitations
- This is a starter/MVP, not a fully audited trading terminal.
- Strategy/backtest implementation is intentionally basic and illustrative. Results are not investment advice and should not be treated as predictive.
- Paper-trading ledger is in-memory for this starter; persist it using Room before release.
- Chart currently draws candles; full indicator overlays, advanced drawing tools, and robust multi-timeframe backtest engine are next milestones.
- Do not put exchange API secrets in the Android app. Public market data requires no key.
- Check exchange terms, regional availability, chart-library licensing, and applicable Indian laws/compliance before release.

## Suggested production architecture
`Compose UI → ViewModel/UseCases → MarketDataProvider → Exchange REST/WebSocket`
`StrategyEngine → Signal/Alert pipeline → FCM backend`
`BacktestEngine ← historical candle repository`
`PaperTradingEngine → Room database`
`Backend (optional) → multi-exchange normalization, scheduled alerts, cloud sync, subscription entitlements`

## Release metadata
App name: CryptoPulse
Version: 1.1 (versionCode 2)
Release label: October 2026
Copyright: All rights reserved.
Creator: Vicky Bhalerao
